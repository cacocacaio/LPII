package br.com.herbertrausch.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.herbertrausch.spring.mongo.Cliente;
import br.com.herbertrausch.spring.mongo.ClienteService;
import br.com.herbertrausch.spring.mongo.Endereco;

@Path("/usuarios")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class UsuarioResource {

	UsuarioService service = new UsuarioService();
	
	@GET
	public List<Usuario> get() {
		
		return service.getAll();
		
	}
	
	@GET
	@Path("/usuarios/{nome}")
	public List<Usuarios> getByNome(@PathParam("nome") String nome) {
		return service.getByNome(nome);
	}
	
	@POST
	public void save(Cliente e){
		
		service.insert(e);
		
	}

}
